"""
test_integracion.py

Integración entre el microservicio en Python y el motor lógico
salud_bienestar.pl.
"""

from pathlib import Path
from typing import Any

from pyswip import Prolog


class MotorSaludBienestar:
    """Wrapper en Python sobre el motor de inferencia Prolog."""

    def __init__(self, ruta_archivo_pl: str = "salud_bienestar.pl") -> None:
        ruta = Path(ruta_archivo_pl)
        if not ruta.is_absolute():
            ruta = Path(__file__).resolve().parent / ruta
        if not ruta.exists():
            raise FileNotFoundError(f"No se encontró el archivo Prolog: {ruta}")

        self.prolog = Prolog()
        self.prolog.consult(str(ruta))

    @staticmethod
    def _lista_prolog(condiciones_python: list[str]) -> str:
        """Convierte una lista de Python en una lista válida de Prolog."""
        return "[" + ",".join(condiciones_python) + "]"

    @staticmethod
    def _convertir(valor: Any) -> Any:
        """Convierte valores de PySwip en tipos serializables como JSON."""
        if isinstance(valor, list):
            return [MotorSaludBienestar._convertir(elemento) for elemento in valor]
        if isinstance(valor, dict):
            return {
                str(clave): MotorSaludBienestar._convertir(contenido)
                for clave, contenido in valor.items()
            }
        if isinstance(valor, bytes):
            return valor.decode("utf-8")
        if isinstance(valor, (str, int, float, bool)) or valor is None:
            return valor
        return str(valor)

    def alimentos_recomendados(self, condiciones: list[str]) -> list[str]:
        cond = self._lista_prolog(condiciones)
        resultados = list(self.prolog.query(f"alimentos_recomendados({cond}, X)"))
        return self._convertir(resultados[0]["X"]) if resultados else []

    def rutina_segura(
        self,
        condiciones: list[str],
        nivel_actividad: str,
    ) -> list[str]:
        cond = self._lista_prolog(condiciones)
        consulta = f"rutina_segura_nombres({cond}, {nivel_actividad}, X)"
        resultados = list(self.prolog.query(consulta))
        return self._convertir(resultados[0]["X"]) if resultados else []

    def beneficios_de_actividad(self, nombre_actividad: str) -> list[str]:
        resultados = list(
            self.prolog.query(f"beneficios_actividad({nombre_actividad}, X)")
        )
        return self._convertir(resultados[0]["X"]) if resultados else []

    def habitos_descanso(self, nivel_estres: str, horas_actuales: int) -> dict:
        consulta = (
            f"habitos_descanso_flat({nivel_estres}, {horas_actuales}, Min, Max, P)"
        )
        resultados = list(self.prolog.query(consulta))
        if not resultados:
            return {}

        resultado = resultados[0]
        return {
            "horas_sueno_min": self._convertir(resultado["Min"]),
            "horas_sueno_max": self._convertir(resultado["Max"]),
            "practicas_higiene_sueno": self._convertir(resultado["P"]),
        }

    def combinacion_optima(
        self,
        objetivo: str,
        condiciones: list[str],
        nivel_actividad: str,
    ) -> dict:
        cond = self._lista_prolog(condiciones)
        consulta = (
            f"combinacion_optima_flat({objetivo}, {cond}, "
            f"{nivel_actividad}, Dieta, Ejercicio)"
        )
        resultados = list(self.prolog.query(consulta))
        if not resultados:
            return {"dieta": [], "ejercicio": []}

        resultado = resultados[0]
        return {
            "dieta": self._convertir(resultado["Dieta"]),
            "ejercicio": self._convertir(resultado["Ejercicio"]),
        }

    def perfil_completo(
        self,
        condiciones: list[str],
        nivel_actividad: str,
        objetivo: str,
        nivel_estres: str,
        horas_sueno: int,
    ) -> dict:
        """Une las consultas del motor en un diccionario listo para JSON."""
        rutina = self.rutina_segura(condiciones, nivel_actividad)
        beneficios = {
            actividad: self.beneficios_de_actividad(actividad)
            for actividad in rutina
        }

        return {
            "condiciones": condiciones,
            "alimentos_recomendados": self.alimentos_recomendados(condiciones),
            "rutina_segura": rutina,
            "beneficios_actividades": beneficios,
            "habitos_descanso": self.habitos_descanso(
                nivel_estres,
                horas_sueno,
            ),
            "combinacion_optima_objetivo": self.combinacion_optima(
                objetivo,
                condiciones,
                nivel_actividad,
            ),
        }


if __name__ == "__main__":
    import json

    motor = MotorSaludBienestar("salud_bienestar.pl")
    perfil = motor.perfil_completo(
        condiciones=["diabetes_tipo2", "obesidad"],
        nivel_actividad="sedentario",
        objetivo="perdida_peso",
        nivel_estres="alto",
        horas_sueno=5,
    )
    print(json.dumps(perfil, indent=2, ensure_ascii=False))
