"""Capa provisional de redacción para sustituir luego por una IA externa."""

from typing import Any


class ServicioIA:
    def generar_recomendacion(self, resultado_prolog: dict[str, Any]) -> str:
        alimentos = self._formatear_lista(
            resultado_prolog.get("alimentos_recomendados", [])
        )
        rutina = self._formatear_lista(resultado_prolog.get("rutina_segura", []))
        descanso = resultado_prolog.get("habitos_descanso", {})
        practicas = self._formatear_lista(
            descanso.get("practicas_higiene_sueno", [])
        )
        minimo = descanso.get("horas_sueno_min", 7)
        maximo = descanso.get("horas_sueno_max", 9)
        ejercicio_objetivo = self._formatear_lista(
            resultado_prolog.get("combinacion_optima_objetivo", {}).get(
                "ejercicio", []
            )
        )

        return (
            "Según el análisis del motor lógico, los alimentos compatibles con "
            f"el perfil son: {alimentos}. Las actividades seguras son: {rutina}. "
            f"Se recomienda dormir entre {minimo} y {maximo} horas y aplicar "
            f"estas prácticas: {practicas}. Para el objetivo seleccionado se "
            f"priorizan estas actividades: {ejercicio_objetivo}. Esta información "
            "es orientativa y no sustituye una valoración profesional de salud."
        )

    @staticmethod
    def _formatear_lista(elementos: list[Any]) -> str:
        if not elementos:
            return "no se encontraron resultados específicos"
        return ", ".join(str(elemento).replace("_", " ") for elemento in elementos)
