"""Funciones para guardar y consultar recomendaciones en SQLite."""

import json
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any

RUTA_BASE_DATOS = Path(__file__).resolve().parent / "salud_bienestar.db"


def obtener_conexion() -> sqlite3.Connection:
    conexion = sqlite3.connect(RUTA_BASE_DATOS, check_same_thread=False)
    conexion.row_factory = sqlite3.Row
    return conexion


def crear_tablas() -> None:
    with obtener_conexion() as conexion:
        conexion.execute(
            """
            CREATE TABLE IF NOT EXISTS recomendaciones (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                usuario_id INTEGER NOT NULL,
                condiciones TEXT NOT NULL,
                nivel_actividad TEXT NOT NULL,
                objetivo TEXT NOT NULL,
                nivel_estres TEXT NOT NULL,
                horas_sueno INTEGER NOT NULL,
                resultado_prolog TEXT NOT NULL,
                recomendacion_ia TEXT NOT NULL,
                fecha_creacion TEXT NOT NULL
            )
            """
        )
        conexion.commit()


def guardar_recomendacion(
    usuario_id: int,
    condiciones: list[str],
    nivel_actividad: str,
    objetivo: str,
    nivel_estres: str,
    horas_sueno: int,
    resultado_prolog: dict[str, Any],
    recomendacion_ia: str,
) -> dict[str, Any]:
    fecha_creacion = datetime.now().isoformat(timespec="seconds")

    with obtener_conexion() as conexion:
        cursor = conexion.execute(
            """
            INSERT INTO recomendaciones (
                usuario_id, condiciones, nivel_actividad, objetivo,
                nivel_estres, horas_sueno, resultado_prolog,
                recomendacion_ia, fecha_creacion
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                usuario_id,
                json.dumps(condiciones, ensure_ascii=False),
                nivel_actividad,
                objetivo,
                nivel_estres,
                horas_sueno,
                json.dumps(resultado_prolog, ensure_ascii=False),
                recomendacion_ia,
                fecha_creacion,
            ),
        )
        conexion.commit()

    return {
        "id": cursor.lastrowid,
        "usuario_id": usuario_id,
        "condiciones": condiciones,
        "nivel_actividad": nivel_actividad,
        "objetivo": objetivo,
        "nivel_estres": nivel_estres,
        "horas_sueno": horas_sueno,
        "resultado_prolog": resultado_prolog,
        "recomendacion_ia": recomendacion_ia,
        "fecha_creacion": fecha_creacion,
    }


def _convertir_registro(registro: sqlite3.Row) -> dict[str, Any]:
    return {
        "id": registro["id"],
        "usuario_id": registro["usuario_id"],
        "condiciones": json.loads(registro["condiciones"]),
        "nivel_actividad": registro["nivel_actividad"],
        "objetivo": registro["objetivo"],
        "nivel_estres": registro["nivel_estres"],
        "horas_sueno": registro["horas_sueno"],
        "resultado_prolog": json.loads(registro["resultado_prolog"]),
        "recomendacion_ia": registro["recomendacion_ia"],
        "fecha_creacion": registro["fecha_creacion"],
    }


def consultar_recomendaciones_usuario(usuario_id: int) -> list[dict[str, Any]]:
    with obtener_conexion() as conexion:
        registros = conexion.execute(
            """
            SELECT * FROM recomendaciones
            WHERE usuario_id = ?
            ORDER BY id DESC
            """,
            (usuario_id,),
        ).fetchall()
    return [_convertir_registro(registro) for registro in registros]


def consultar_recomendacion(recomendacion_id: int) -> dict[str, Any] | None:
    with obtener_conexion() as conexion:
        registro = conexion.execute(
            "SELECT * FROM recomendaciones WHERE id = ?",
            (recomendacion_id,),
        ).fetchone()
    return _convertir_registro(registro) if registro else None
