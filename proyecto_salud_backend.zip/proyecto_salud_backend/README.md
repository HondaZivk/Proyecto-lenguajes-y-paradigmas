# Backend de Salud y Bienestar

## Archivos

- `main.py`: API FastAPI y endpoints.
- `test_integracion.py`: conexión de Python con Prolog.
- `salud_bienestar.pl`: motor lógico de Persona 1.
- `base_datos.py`: almacenamiento de recomendaciones en SQLite.
- `servicio_ia.py`: redacción provisional; luego puede conectarse a una IA externa.

## Requisitos

1. Python 3.10 o superior.
2. SWI-Prolog instalado.
3. En Windows, comprobar en CMD:

```bash
swipl --version
```

## Instalación

Desde la carpeta del proyecto:

```bash
python -m venv .venv
```

Activar en Windows:

```bash
.venv\Scripts\activate
```

Instalar paquetes:

```bash
pip install -r requirements.txt
```

## Ejecutar

```bash
uvicorn main:app --reload
```

Abrir la documentación:

```text
http://127.0.0.1:8000/docs
```

## Prueba para POST /recomendaciones

```json
{
  "usuario_id": 1,
  "condiciones": ["diabetes_tipo2", "obesidad"],
  "nivel_actividad": "sedentario",
  "objetivo": "perdida_peso",
  "nivel_estres": "alto",
  "horas_sueno": 5
}
```

La base de datos `salud_bienestar.db` se crea automáticamente.
