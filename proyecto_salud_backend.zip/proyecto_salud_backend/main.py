"""API principal del Sistema Inteligente de Salud y Bienestar."""

from contextlib import asynccontextmanager
from typing import Any, Literal

from fastapi import FastAPI, HTTPException, status
from pydantic import BaseModel, Field, field_validator

from base_datos import (
    consultar_recomendacion,
    consultar_recomendaciones_usuario,
    crear_tablas,
    guardar_recomendacion,
)
from servicio_ia import ServicioIA
from test_integracion import MotorSaludBienestar

CondicionSalud = Literal[
    "diabetes_tipo2",
    "hipertension",
    "hipotiroidismo",
    "obesidad",
    "anemia",
    "intolerancia_lactosa",
    "celiaquia",
    "ninguna",
]
NivelActividad = Literal[
    "sedentario",
    "levemente_activo",
    "moderadamente_activo",
    "muy_activo",
]
ObjetivoBienestar = Literal[
    "perdida_peso",
    "ganancia_muscular",
    "mantenimiento",
    "mejora_cardiovascular",
    "reduccion_estres",
]
NivelEstres = Literal["bajo", "medio", "alto"]


class PerfilSaludEntrada(BaseModel):
    usuario_id: int = Field(gt=0, examples=[1])
    condiciones: list[CondicionSalud] = Field(
        min_length=1,
        examples=[["diabetes_tipo2", "obesidad"]],
    )
    nivel_actividad: NivelActividad = Field(examples=["sedentario"])
    objetivo: ObjetivoBienestar = Field(examples=["perdida_peso"])
    nivel_estres: NivelEstres = Field(examples=["alto"])
    horas_sueno: int = Field(ge=0, le=24, examples=[5])

    @field_validator("condiciones")
    @classmethod
    def eliminar_repetidas(cls, condiciones: list[str]) -> list[str]:
        condiciones_unicas = list(dict.fromkeys(condiciones))
        if "ninguna" in condiciones_unicas and len(condiciones_unicas) > 1:
            raise ValueError("'ninguna' no puede combinarse con otras condiciones.")
        return condiciones_unicas


class RecomendacionRespuesta(BaseModel):
    id: int
    usuario_id: int
    condiciones: list[str]
    nivel_actividad: str
    objetivo: str
    nivel_estres: str
    horas_sueno: int
    resultado_prolog: dict[str, Any]
    recomendacion_ia: str
    fecha_creacion: str


class EstadoAPI(BaseModel):
    api: str
    base_datos: str
    prolog: str
    detalle: str | None = None


motor: MotorSaludBienestar | None = None
error_prolog: str | None = None
servicio_ia = ServicioIA()


@asynccontextmanager
async def ciclo_vida(app: FastAPI):
    global motor, error_prolog
    crear_tablas()
    try:
        motor = MotorSaludBienestar("salud_bienestar.pl")
        error_prolog = None
    except Exception as error:
        motor = None
        error_prolog = str(error)
    yield


app = FastAPI(
    title="Sistema Inteligente de Salud y Bienestar",
    description=(
        "API con FastAPI que conecta el perfil del usuario, el motor Prolog, "
        "la capa de redacción y la base de datos SQLite."
    ),
    version="1.0.0",
    lifespan=ciclo_vida,
)


@app.get("/", tags=["General"])
def inicio() -> dict[str, str]:
    return {
        "mensaje": "API de Salud y Bienestar funcionando.",
        "documentacion": "/docs",
    }


@app.get("/health", response_model=EstadoAPI, tags=["General"])
def verificar_estado() -> EstadoAPI:
    return EstadoAPI(
        api="activa",
        base_datos="conectada",
        prolog="conectado" if motor is not None else "no conectado",
        detalle=error_prolog,
    )


@app.post(
    "/recomendaciones",
    response_model=RecomendacionRespuesta,
    status_code=status.HTTP_201_CREATED,
    tags=["Recomendaciones"],
)
def generar_recomendacion(perfil: PerfilSaludEntrada) -> dict[str, Any]:
    if motor is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=(
                "El motor Prolog no está disponible. Verifique SWI-Prolog, "
                "PySwip y el archivo salud_bienestar.pl."
            ),
        )

    try:
        resultado = motor.perfil_completo(
            condiciones=list(perfil.condiciones),
            nivel_actividad=perfil.nivel_actividad,
            objetivo=perfil.objetivo,
            nivel_estres=perfil.nivel_estres,
            horas_sueno=perfil.horas_sueno,
        )
        texto = servicio_ia.generar_recomendacion(resultado)
        return guardar_recomendacion(
            usuario_id=perfil.usuario_id,
            condiciones=list(perfil.condiciones),
            nivel_actividad=perfil.nivel_actividad,
            objetivo=perfil.objetivo,
            nivel_estres=perfil.nivel_estres,
            horas_sueno=perfil.horas_sueno,
            resultado_prolog=resultado,
            recomendacion_ia=texto,
        )
    except Exception as error:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"No fue posible generar la recomendación: {error}",
        ) from error


@app.get(
    "/recomendaciones/usuario/{usuario_id}",
    response_model=list[RecomendacionRespuesta],
    tags=["Recomendaciones"],
)
def historial_usuario(usuario_id: int) -> list[dict[str, Any]]:
    if usuario_id <= 0:
        raise HTTPException(status_code=400, detail="El usuario_id debe ser positivo.")
    return consultar_recomendaciones_usuario(usuario_id)


@app.get(
    "/recomendaciones/{recomendacion_id}",
    response_model=RecomendacionRespuesta,
    tags=["Recomendaciones"],
)
def recomendacion_por_id(recomendacion_id: int) -> dict[str, Any]:
    registro = consultar_recomendacion(recomendacion_id)
    if registro is None:
        raise HTTPException(status_code=404, detail="La recomendación no existe.")
    return registro
