% archivo: nl_templates.pl
% Define plantillas para predicados comunes

% persona(Nombre, Edad).
nl_sentence(persona(Nombre, Edad), Sentence) :-
    format(atom(Sentence), '~w tiene ~w años.', [Nombre, Edad]).

% vive_en(Nombre, Ciudad).
nl_sentence(vive_en(Nombre, Ciudad), Sentence) :-
    format(atom(Sentence), '~w vive en ~w.', [Nombre, Ciudad]).

% le_gusta(Nombre, ListaCosas).
nl_sentence(le_gusta(Nombre, Cosas), Sentence) :-
    is_list(Cosas),
    list_to_comma_and(Cosas, CosasText),
    format(atom(Sentence), '~w le gusta ~w.', [Nombre, CosasText]).

% Auxiliar: convierte lista en "a, b y c"
list_to_comma_and([], '').
list_to_comma_and([X], X).
list_to_comma_and([A,B], Text) :-
    format(atom(Text), '~w y ~w', [A,B]).
list_to_comma_and([H|T], Text) :-
    T \= [],
    append(Init, [Last], [H|T]),
    atomic_list_concat(Init, ', ', InitText),
    format(atom(Text), '~w y ~w', [InitText, Last]).
