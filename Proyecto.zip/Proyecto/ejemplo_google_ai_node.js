// ejemplo_google_ai_node.js
// Requisitos: npm install @google-cloud/aiplatform
const {PredictionServiceClient} = require('@google-cloud/aiplatform').v1;

const PROJECT_ID = "tu-project-id";   // reemplaza
const LOCATION = "us-central1";       // o la región que uses
const MODEL = "text-bison@001";       // ejemplo

async function generarTexto(prompt, maxOutputTokens = 256, temperature = 0.2) {
  const client = new PredictionServiceClient();

  const endpoint = `projects/${PROJECT_ID}/locations/${LOCATION}/publishers/google/models/${MODEL}`;

  const instance = { content: prompt };
  const parameters = {
    temperature: temperature,
    maxOutputTokens: maxOutputTokens
  };

  const request = {
    endpoint: endpoint,
    instances: [instance],
    parameters: parameters
  };

  const [response] = await client.predict(request);

  if (response.predictions && response.predictions.length > 0) {
    const pred = response.predictions[0];
    return pred.content || JSON.stringify(pred);
  }
  return JSON.stringify(response);
}

(async () => {
  try {
    const prompt = "Genera 4 ideas creativas para un proyecto escolar sobre reciclaje.";
    const out = await generarTexto(prompt, 120, 0.3);
    console.log("=== Resultado ===");
    console.log(out);
  } catch (err) {
    console.error("Error:", err);
  }
})();
