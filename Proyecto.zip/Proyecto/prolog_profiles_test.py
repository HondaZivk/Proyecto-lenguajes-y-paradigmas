# prolog_profiles_test.py
# Ejecutar: python prolog_profiles_test.py

import re

# --- Plantillas por perfil ---
def fmt_formal(pred, args):
    if pred == "persona":
        return f"{args[0]} tiene {args[1]} años."
    if pred == "vive_en":
        return f"{args[0]} reside en {args[1]}."
    if pred == "le_gusta":
        return f"A {args[0]} le agradan {list_to_text(args[1])}."
    return generic_fallback(pred, args)

def fmt_casual(pred, args):
    if pred == "persona":
        return f"{args[0]} tiene {args[1]} años."
    if pred == "vive_en":
        return f"{args[0]} vive en {args[1]}."
    if pred == "le_gusta":
        return f"A {args[0]} le gusta {list_to_text(args[1])}."
    return generic_fallback(pred, args)

def fmt_tecnico(pred, args):
    if pred == "persona":
        return f"persona(nombre={args[0]}, edad={args[1]})"
    if pred == "vive_en":
        return f"vive_en(persona={args[0]}, ciudad={args[1]})"
    if pred == "le_gusta":
        return f"le_gusta(persona={args[0]}, gustos={args[1]})"
    return generic_fallback(pred, args)

def fmt_ninos(pred, args):
    if pred == "persona":
        return f"{args[0]} tiene {args[1]} años. ¡Qué bien!"
    if pred == "vive_en":
        return f"{args[0]} vive en {args[1]}."
    if pred == "le_gusta":
        return f"A {args[0]} le gusta {list_to_text(args[1])}."
    return generic_fallback(pred, args)

def fmt_conciso(pred, args):
    if pred == "persona":
        return f"{args[0]}: {args[1]} años."
    if pred == "vive_en":
        return f"{args[0]}: {args[1]}."
    if pred == "le_gusta":
        return f"{args[0]}: {', '.join(args[1])}."
    return generic_fallback(pred, args)

PROFILES = {
    "formal": fmt_formal,
    "casual": fmt_casual,
    "tecnico": fmt_tecnico,
    "ninos": fmt_ninos,
    "conciso": fmt_conciso
}

# --- Helpers ---
def list_to_text(lst):
    if not lst:
        return ""
    if len(lst) == 1:
        return lst[0]
    if len(lst) == 2:
        return f"{lst[0]} y {lst[1]}"
    return f"{', '.join(lst[:-1])} y {lst[-1]}"

def generic_fallback(pred, args):
    args_text = ", ".join([str(a) for a in args])
    return f"{pred}({args_text})."

def parse_prolog_term(s):
    s = s.strip().rstrip('.')
    m = re.match(r'^([a-zA-Z_]\w*)\((.*)\)$', s)
    if not m:
        return None, []
    pred = m.group(1)
    inner = m.group(2).strip()
    # split top-level commas
    args = []
    depth = 0
    cur = ""
    for ch in inner:
        if ch == ',' and depth == 0:
            args.append(cur.strip())
            cur = ""
        else:
            cur += ch
            if ch in "([": depth += 1
            if ch in ")]": depth -= 1
    if cur:
        args.append(cur.strip())
    # clean args
    clean = []
    for a in args:
        a = a.strip()
        if a.startswith('[') and a.endswith(']'):
            inner = a[1:-1].strip()
            if inner == "":
                clean.append([])
            else:
                parts = [p.strip().strip("'\"") for p in inner.split(',')]
                clean.append(parts)
        else:
            clean.append(a.strip("'\""))
    return pred, clean

# --- Test runner ---
def run_tests(prolog_outputs):
    results = {}
    for profile_name, func in PROFILES.items():
        out_lines = []
        for term in prolog_outputs:
            pred, args = parse_prolog_term(term)
            if pred is None:
                out_lines.append("[No se pudo parsear: {}]".format(term))
            else:
                out_lines.append(func(pred, args))
        results[profile_name] = out_lines
    return results

# --- Ejemplo de entradas Prolog ---
prolog_outputs = [
    "persona('Ana',30).",
    "vive_en('Luis','San José').",
    "le_gusta('María',['leer','pintar','cantar']).",
    "amigo('Pedro','Juan')."
]

if __name__ == "__main__":
    res = run_tests(prolog_outputs)
    for profile, lines in res.items():
        print("=== Perfil:", profile, "===")
        for i, l in enumerate(lines, 1):
            print(f"{i}. {l}")
        print()
