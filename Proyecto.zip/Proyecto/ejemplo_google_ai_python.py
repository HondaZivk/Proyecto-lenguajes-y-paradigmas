# ejemplo_google_ai_python.py
# Requisitos: pip install google-cloud-aiplatform google-auth

from google.cloud import aiplatform
import os

# --- CONFIGURACIÓN ---
PROJECT_ID = "tu-project-id"        # reemplaza
LOCATION = "us-central1"            # o la región que uses
MODEL = "text-bison@001"            # ejemplo de modelo de texto de Google Generative AI
# Asegúrate de tener GOOGLE_APPLICATION_CREDENTIALS apuntando al JSON de la cuenta de servicio

def generar_texto(prompt: str, max_output_tokens: int = 256, temperature: float = 0.2):
    """
    Genera texto usando el modelo especificado en Google Generative AI (Vertex AI).
    """
    client = aiplatform.gapic.PredictionServiceClient()
    endpoint = f"projects/{PROJECT_ID}/locations/{LOCATION}/publishers/google/models/{MODEL}"

    # Construir la petición según el formato de la API
    instance = {
        "content": prompt
    }
    parameters = {
        "temperature": temperature,
        "maxOutputTokens": max_output_tokens
    }

    response = client.predict(
        endpoint=endpoint,
        instances=[instance],
        parameters=parameters
    )

    # La respuesta puede contener múltiples predicciones; aquí tomamos la primera
    if response.predictions:
        # Dependiendo de la versión, la estructura puede variar; convertimos a string
        return response.predictions[0].get("content", str(response.predictions[0]))
    return str(response)

if __name__ == "__main__":
    prompt = "Escribe un breve resumen (3-4 líneas) sobre la importancia de la energía renovable."
    try:
        salida = generar_texto(prompt, max_output_tokens=120, temperature=0.3)
        print("=== Resultado ===")
        print(salida)
    except Exception as e:
        print("Error al invocar la API:", e)


