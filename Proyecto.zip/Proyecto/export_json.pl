% archivo: export_json.pl
:- use_module(library(http/json)).

persona('Ana', 30).
le_gusta('Luis', ['leer','correr','cocinar']).

export_personas_json :-
    findall(_{nombre:Name, edad:Age}, persona(Name, Age), L),
    open('personas.json', write, S),
    json_write_dict(S, L),
    close(S).
