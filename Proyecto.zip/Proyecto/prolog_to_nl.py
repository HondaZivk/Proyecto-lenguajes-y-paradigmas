# prolog_to_nl.py
# Requisitos: tener swipl (SWI-Prolog) instalado y accesible.
# Uso: python prolog_to_nl.py

import subprocess
import json
import shlex
import re

# --- Configuración: mapeo de predicados a plantillas ---
# Cada clave: nombre del predicado; valor: función que recibe lista de args y devuelve frase.
def persona_template(args):
    name, age = args
    return f"{name} tiene {age} años."

def vive_en_template(args):
    name, city = args
    return f"{name} vive en {city}."

def le_gusta_template(args):
    name, items = args
    # items: lista de strings
    if not items:
        return f"{name} no ha indicado gustos."
    if len(items) == 1:
        return f"{name} le gusta {items[0]}."
    if len(items) == 2:
        return f"{name} le gusta {items[0]} y {items[1]}."
    return f"{name} le gusta {', '.join(items[:-1])} y {items[-1]}."

TEMPLATES = {
    'persona': persona_template,
    'vive_en': vive_en_template,
    'le_gusta': le_gusta_template
}

# --- Helpers ---
def parse_prolog_term(term_str):
    """
    Parse un término Prolog simple como persona('Ana',30) o le_gusta('Luis',['leer','correr'])
    Devuelve (predicado, [arg1, arg2, ...]) con strings limpios y listas como listas Python.
    Nota: esto es un parser simple; para casos complejos conviene usar un parser Prolog real.
    """
    term_str = term_str.strip().rstrip('.')
    m = re.match(r'^([a-zA-Z_]\w*)\((.*)\)$', term_str)
    if not m:
        return None, []
    pred = m.group(1)
    args_str = m.group(2).strip()
    # Split top-level commas (no manejo de paréntesis anidados profundo)
    args = []
    depth = 0
    cur = ''
    for ch in args_str:
        if ch == ',' and depth == 0:
            args.append(cur.strip())
            cur = ''
        else:
            cur += ch
            if ch == '[':
                depth += 1
            elif ch == ']':
                depth -= 1
            elif ch == '(':
                depth += 1
            elif ch == ')':
                depth -= 1
    if cur:
        args.append(cur.strip())
    # Limpieza de args: quitar comillas y convertir listas
    clean_args = []
    for a in args:
        a = a.strip()
        # lista Prolog: ['a','b']
        if a.startswith('[') and a.endswith(']'):
            inner = a[1:-1].strip()
            if inner == '':
                clean_args.append([])
            else:
                # split por comas top-level
                parts = [p.strip() for p in re.split(r'\s*,\s*', inner)]
                parts = [p.strip("'\"") for p in parts]
                clean_args.append(parts)
        else:
            clean_args.append(a.strip("'\""))
    return pred, clean_args

def prolog_query_to_sentences(prolog_query, prolog_file=None):
    """
    Ejecuta una consulta Prolog y convierte la(s) solución(es) en oraciones naturales.
    prolog_query: string con la consulta, p.ej. "persona(X,Y)."
    prolog_file: archivo .pl con definiciones (opcional)
    """
    # Construir comando swipl para ejecutar la consulta y mostrar soluciones en forma de términos
    # Usamos formato write/1 para imprimir términos concretos; el usuario puede adaptar la consulta.
    swipl_cmd = "swipl -q -t halt -s /dev/stdin"
    # Construimos un programa Prolog temporal que carga archivo si existe y ejecuta la consulta
    prolog_program = ""
    if prolog_file:
        prolog_program += f":- consult('{prolog_file}').\n"
    # Imprimir cada solución como término con writeq/1 y newline
    prolog_program += f"query :- ({prolog_query} -> (writeq(({prolog_query})), nl, fail); true).\n"
    prolog_program += ":- query.\n"
    # Ejecutar swipl
    try:
        proc = subprocess.run(shlex.split(swipl_cmd), input=prolog_program.encode('utf-8'),
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE, check=True)
    except subprocess.CalledProcessError as e:
        print("Error ejecutando SWI-Prolog:", e.stderr.decode())
        return []
    output = proc.stdout.decode('utf-8').strip().splitlines()
    sentences = []
    for line in output:
        pred, args = parse_prolog_term(line)
        if pred in TEMPLATES:
            try:
                sentence = TEMPLATES[pred](args)
                sentences.append(sentence)
            except Exception:
                sentences.append(f"[No se pudo formatear {line}]")
        else:
            sentences.append(f"[Sin plantilla para: {line}]")
    return sentences

# --- Ejemplo de uso local (sin archivo .pl) ---
if __name__ == "__main__":
    # Ejemplo: si tienes un archivo datos.pl con hechos, pasa prolog_file='datos.pl'
    # Aquí mostramos cómo sería la llamada (requiere adaptar la consulta)
    # sentences = prolog_query_to_sentences("persona('Ana',30).", prolog_file='datos.pl')
    # print("\n".join(sentences))
    print("Este script necesita SWI-Prolog y una consulta válida. Adapta prolog_query_to_sentences para tu caso.")
